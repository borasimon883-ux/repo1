package libcore

import (
	"net/netip"

	tun "github.com/sagernet/sing-tun"
	"github.com/sagernet/sing/common/control"
	"github.com/sagernet/sing/common/x/list"
)

// wtf

type interfaceMonitor struct {
	myInterface string
}

func (i *interfaceMonitor) Start() error {
	return nil
}

func (i *interfaceMonitor) Close() error {
	return nil
}

func (i *interfaceMonitor) DefaultInterfaceName(destination netip.Addr) string {
	return ""
}

func (i *interfaceMonitor) DefaultInterfaceIndex(destination netip.Addr) int {
	return 0
}

func (i *interfaceMonitor) DefaultInterface() *control.Interface {
	return nil
}

func (i *interfaceMonitor) OverrideAndroidVPN() bool {
	return false
}

func (i *interfaceMonitor) AndroidVPNEnabled() bool {
	return false
}

func (i *interfaceMonitor) RegisterCallback(callback tun.DefaultInterfaceUpdateCallback) *list.Element[tun.DefaultInterfaceUpdateCallback] {
	return nil
}

func (i *interfaceMonitor) UnregisterCallback(element *list.Element[tun.DefaultInterfaceUpdateCallback]) {}

func (i *interfaceMonitor) RegisterMyInterface(interfaceName string) { i.myInterface = interfaceName }

func (i *interfaceMonitor) MyInterface() string { return i.myInterface }
