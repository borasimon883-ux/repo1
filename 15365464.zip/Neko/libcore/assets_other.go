//go:build !android

package libcore

func extractAssets() {}
