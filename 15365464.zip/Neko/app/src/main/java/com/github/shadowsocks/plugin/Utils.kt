@file:JvmName("Utils")

package com.github.shadowsocks.plugin

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
class Empty : Parcelable