#!/bin/sh
# cp local.properties external/editorkit/
# cp local.properties external/termux-view/
